This release includes FOTA update from mfw_nrf9160_1.3.1 release to mfw_nrf9160_1.3.3 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.1_to_1.3.3.bin.

This release includes FOTA update from mfw_nrf9160_1.3.2 release to mfw_nrf9160_1.3.3 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.2_to_1.3.3.bin.

Non-wired full modem update can be performed by using new MFW CBOR image format and suitable support from the nRF Connect SDK and device hardware.

This release includes FOTA-TEST images between mfw_nrf9160_1.3.3 release and mfw_nrf9160_1.3.3-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.3.3_to_1.3.3-FOTA-TEST and mfw_nrf9160_update_from_1.3.3-FOTA-TEST_to_1.3.3.

UUID of mfw_nrf9160_1.3.3 is 84f941be-2a17-4f30-9809-ae96c1deba40
UUID of mfw_nrf9160_1.3.3-FOTA-TEST is 9cedd460-5c17-4c00-888b-058f0645a05f