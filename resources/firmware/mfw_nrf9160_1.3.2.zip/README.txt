This release includes FOTA update from mfw_nrf9160_1.3.1 release to mfw_nrf9160_1.3.2 release.
FOTA update filename is mfw_nrf9160_update_from_1.3.1_to_1.3.2.bin.

Non-wired full modem update can be performed by using new MFW CBOR image format and suitable support from the nRF Connect SDK and device hardware.

This release includes FOTA-TEST images between mfw_nrf9160_1.3.2 release and mfw_nrf9160_1.3.2-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.3.2_to_1.3.2-FOTA-TEST and mfw_nrf9160_update_from_1.3.2-FOTA-TEST_to_1.3.2.

UUID of mfw_nrf9160_1.3.2 is c816a44f-c0da-43f3-a72a-92102cd8e13b
UUID of mfw_nrf9160_1.3.2-FOTA-TEST is 4ccd5f94-3209-4a7b-9062-6b7dc75db31a